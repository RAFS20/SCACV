package Simulador;
public interface Observador {
	public void actualizar();
}